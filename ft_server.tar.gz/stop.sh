docker stop ft_server > /dev/null
docker rm ft_server > /dev/null